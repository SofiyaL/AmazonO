package com.abc.amozon1;

import java.util.Scanner;

public class Laptop {
	
	public static void laptop()
	{
		boolean laptopmenu=true;
		boolean hpmenu;
		boolean dellmenu;
		boolean acermenu;
	while(laptopmenu)
	{
		Scanner scan=new Scanner(System.in);
		System.out.println("Please choose Laptop Brand \n1.HP\n2.Dell\n3.Acer\n4.Back to Previous Menu\n5.Exit");
		int mobileoption=scan.nextInt();
		switch(mobileoption)
		{
		case 1:
		hpmenu=true;
		while(hpmenu)
		{
			System.out.println("Please select Model from below list");
			System.out.printf("%-5s %-15s %-2s %s\n","S.NO","Model",":","Price");
			System.out.printf("%-5s %-15s %-2s %s\n","1","15Q-DY7AU",":","22,990");
			System.out.printf("%-5s %-15s %-2s %s\n","2","14Q-CS23TU",":","32,490");
			System.out.printf("%-5s %-15s %-2s %s\n","3","15-BC406TX",":","54,990");
			System.out.println("4 : Back to previous menu");
			int lgmodel=scan.nextInt();
			switch(lgmodel)
			{
			case 1:
				String hp1="15Q-DY7AU";
				int hp1Price=22990;
				System.out.println("Enter Quantity");
				int hp1q=scan.nextInt();
				new Cart().cart(hp1, hp1q);
				new Cart().price(hp1, hp1Price);
				System.out.println("HP 15Q-DY7AU added to Shopping Cart");
				System.out.println("**********************");
				break;
			
			case 2:
				String hp2="43UM729";
				int hp2Price=32490;
				System.out.println("Enter Quantity");
				int hp2q=scan.nextInt();
				new Cart().cart(hp2, hp2q);
				new Cart().price(hp2, hp2Price);
				System.out.println("HP 14Q-CS23TU added to Shopping Cart");
				System.out.println("**********************");
				break;
			
			case 3:
				String hp3="15-BC406TX";
				int hp3Price=54990;
				System.out.println("Enter Quantity");
				int hp3q=scan.nextInt();
				new Cart().cart(hp3, hp3q);
				new Cart().price(hp3, hp3Price);
				System.out.println("HP 15-BC406TX added to Shopping Cart");
				System.out.println("**********************");
				break;
			
			case 4:
			hpmenu=false;
			break;
			
			default:
				System.out.println("Invalid choice");
				break;
			}
		}break;
		
		case 2:
			dellmenu=true;
			while(dellmenu)
			{
				System.out.println("Please select Model from below list");
				System.out.printf("%-5s %-14s %-2s %s\n","S.NO","Model",":","Price");
				System.out.printf("%-5s %-14s %-2s %s\n","1","Inspiron 3481",":","24,990");
				System.out.printf("%-5s %-14s %-2s %s\n","2","Vostro 3480",":","34,990");
				System.out.printf("%-5s %-14s %-2s %s\n","3","Inspiron 3576",":","48,990");
				System.out.println("4.Back to previous menu");
				int dellmodel=scan.nextInt();
				switch(dellmodel)
				{
				case 1:
					String dell1="Inspiron 3481";
					int dell1Price=24990;
					System.out.println("Enter Quantity");
					int dell1q=scan.nextInt();
					new Cart().cart(dell1, dell1q);
					new Cart().price(dell1, dell1Price);
					System.out.println("Dell Inspiron 3481 added to Shopping Cart");
					System.out.println("**********************");
					break;
				
				case 2:
					String dell2="Vostro 3480";
					int dell2Price=34990;
					System.out.println("Enter Quantity");
					int dell2q=scan.nextInt();
					new Cart().cart(dell2, dell2q);
					new Cart().price(dell2, dell2Price);
					System.out.println("Dell Vostro 3480 added to Shopping Cart");
					System.out.println("**********************");
					break;
				
				case 3:
					String dell3="";
					int dell3Price=48990;
					System.out.println("Enter Quantity");
					int dell3q=scan.nextInt();
					new Cart().cart(dell3, dell3q);
					new Cart().price(dell3, dell3Price);
					System.out.println("Dell Inspiron 3576 added to Shopping Cart");
					System.out.println("**********************");
					break;
				
				case 4:
				dellmenu=false;
				break;
				
				default:
					System.out.println("Invalid choice");
					break;
				}
			}break;
			
		case 3:
			acermenu=true;
			while(acermenu)
			{
				System.out.println("Please select Model from below list");
				System.out.printf("%-5s %-7s %-2s %s\n","S.NO","Model",":","Price");
				System.out.printf("%-5s %-7s %-2s %s\n","1","Aspire 3",":","17,990");
				System.out.printf("%-5s %-7s %-2s %s\n","2","Aspire A315",":","42,990");
				System.out.printf("%-5s %-7s %-2s %s\n","3","Nitro AN515",":","49,999");
				System.out.println("4 Back to previous menu");
				int acermodel=scan.nextInt();
				switch(acermodel)
				{
				case 1:
					String acer1="Aspire 3";
					int acer1Price=17990;
					System.out.println("Enter Quantity");
					int acer1q=scan.nextInt();
					new Cart().cart(acer1, acer1q);
					new Cart().price(acer1, acer1Price);
					System.out.println("Acer Aspire 3 added to Shopping Cart");
					System.out.println("**********************");
					break;
				
				case 2:
					String acer2="Aspire A315";
					int acer2Price=42990;
					System.out.println("Enter Quantity");
					int acer2q=scan.nextInt();
					new Cart().cart(acer2, acer2q);
					new Cart().price(acer2, acer2Price);
					System.out.println("Acer Aspire A315 added to Shopping Cart");					
					System.out.println("**********************");
					break;
				
				case 3:
					String acer3="Nitro AN515";
					int acer3Price=54999;
					System.out.println("Enter Quantity");
					int acer3q=scan.nextInt();
					new Cart().cart(acer3, acer3q);
					new Cart().price(acer3, acer3Price);
					System.out.println("Acer Nitro AN515 added to Shopping Cart");
					System.out.println("**********************");
					break;
				
				case 4:
				acermenu=false;
				break;
				
				default:
					System.out.println("Invalid choice");
					break;
				}
			}break;
			
		case 4:
			laptopmenu=false;
			break;
			
		case 5:
			System.exit(0);
			break;
		
			default:
			System.out.println("Invalid choice");
			break;
			

}
	}
	}

}
