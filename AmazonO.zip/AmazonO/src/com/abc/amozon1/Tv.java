package com.abc.amozon1;

import java.util.Scanner;

public class Tv {
	
	public static void tv()
	{
		boolean tvmenu=true;
		boolean lgmenu;
		boolean vumenu;
		boolean mimenu;
	while(tvmenu)
	{
		Scanner scan=new Scanner(System.in);
		System.out.println("Please choose TV Brand \n1.LG\n2.MI\n3.VU\n4.Back to Previous Menu\n5.Exit");
		int mobileoption=scan.nextInt();
		switch(mobileoption)
		{
		case 1:
		lgmenu=true;
		while(lgmenu)
		{
			System.out.println("Please select Model from below list");
			System.out.printf("%-5s %-15s %-2s %s\n","S.NO","Model",":","Price");
			System.out.printf("%-5s %-15s %-2s %s\n","1","32LM560",":","15,499");
			System.out.printf("%-5s %-15s %-2s %s\n","2","43UM729",":","35,999");
			System.out.printf("%-5s %-15s %-2s %s\n","3","55UM729",":","54,999");
			System.out.println("4 : Back to previous menu");
			int lgmodel=scan.nextInt();
			switch(lgmodel)
			{
			case 1:
				String lgtv1="32LM560";
				int lgtv1Price=15499;
				System.out.println("Enter Quantity");
				int lgtv1q=scan.nextInt();
				new Cart().cart(lgtv1, lgtv1q);
				new Cart().price(lgtv1, lgtv1Price);
				System.out.println("LG 43UM729 added to Shopping Cart");
				System.out.println("**********************");
				break;
			
			case 2:
				String lgtv2="43UM729";
				int lgtv2Price=35999;
				System.out.println("Enter Quantity");
				int lgtv2q=scan.nextInt();
				new Cart().cart(lgtv2, lgtv2q);
				new Cart().price(lgtv2, lgtv2Price);
				System.out.println("LG 43UM729 added to Shopping Cart");
				System.out.println("**********************");
				break;
			
			case 3:
				String lgtv3="55UM729";
				int lgtv3Price=54999;
				System.out.println("Enter Quantity");
				int lgtv3q=scan.nextInt();
				new Cart().cart(lgtv3, lgtv3q);
				new Cart().price(lgtv3, lgtv3Price);
				System.out.println("LG 55UM729 added to Shopping Cart");
				System.out.println("**********************");
				break;
			
			case 4:
			lgmenu=false;
			break;
			
			default:
				System.out.println("Invalid choice");
				break;
			}
		}break;
		
		case 2:
			mimenu=true;
			while(mimenu)
			{
				System.out.println("Please select Model from below list");
				System.out.printf("%-5s %-14s %-2s %s\n","S.NO","Model",":","Price");
				System.out.printf("%-5s %-14s %-2s %s\n","1","4A PRO",":","21,999");
				System.out.printf("%-5s %-14s %-2s %s\n","2","4X 50",":","29,999");
				System.out.printf("%-5s %-14s %-2s %s\n","3","4X PRO",":","49,999");
				System.out.println("4.Back to previous menu");
				int sonymodel=scan.nextInt();
				switch(sonymodel)
				{
				case 1:
					String mitv1="4A-PRO";
					int mitv1Price=21999;
					System.out.println("Enter Quantity");
					int mitv1q=scan.nextInt();
					new Cart().cart(mitv1, mitv1q);
					new Cart().price(mitv1, mitv1Price);
					System.out.println("MI 4A PRO added to Shopping Cart");
					System.out.println("**********************");
					break;
				
				case 2:
					String mitv2="4X 50";
					int mitv2Price=29990;
					System.out.println("Enter Quantity");
					int mitv2q=scan.nextInt();
					new Cart().cart(mitv2, mitv2q);
					new Cart().price(mitv2, mitv2Price);
					System.out.println("MI 4X 50 added to Shopping Cart");
					System.out.println("**********************");
					break;
				
				case 3:
					String mitv3="";
					int mitv3Price=49999;
					System.out.println("Enter Quantity");
					int mitv3q=scan.nextInt();
					new Cart().cart(mitv3, mitv3q);
					new Cart().price(mitv3, mitv3Price);
					System.out.println("MI 4X PRO added to Shopping Cart");
					System.out.println("**********************");
					break;
				
				case 4:
				mimenu=false;
				break;
				
				default:
					System.out.println("Invalid choice");
					break;
				}
			}break;
			
		case 3:
			vumenu=true;
			while(vumenu)
			{
				System.out.println("Please select Model from below list");
				System.out.printf("%-5s %-7s %-2s %s\n","S.NO","Model",":","Price");
				System.out.printf("%-5s %-7s %-2s %s\n","1","40SM",":","16,999");
				System.out.printf("%-5s %-7s %-2s %s\n","2","50A",":","35,900");
				System.out.printf("%-5s %-7s %-2s %s\n","3","65BPX",":","54,999");
				System.out.println("4 Back to previous menu");
				int vumodel=scan.nextInt();
				switch(vumodel)
				{
				case 1:
					String vutv1="40SM";
					int vutv1Price=16999;
					System.out.println("Enter Quantity");
					int vutv1q=scan.nextInt();
					new Cart().cart(vutv1, vutv1q);
					new Cart().price(vutv1, vutv1Price);
					System.out.println("VU 40SM added to Shopping Cart");
					System.out.println("**********************");
					break;
				
				case 2:
					String vutv2="50A";
					int vutv2Price=35900;
					System.out.println("Enter Quantity");
					int vutv2q=scan.nextInt();
					new Cart().cart(vutv2, vutv2q);
					new Cart().price(vutv2, vutv2Price);
					System.out.println("VU 50A added to Shopping Cart");					
					System.out.println("**********************");
					break;
				
				case 3:
					String vutv3="65BPX";
					int vutv3Price=54999;
					System.out.println("Enter Quantity");
					int vutv3q=scan.nextInt();
					new Cart().cart(vutv3, vutv3q);
					new Cart().price(vutv3, vutv3Price);
					System.out.println("VU 65BPX added to Shopping Cart");
					System.out.println("**********************");
					break;
				
				case 4:
				vumenu=false;
				break;
				
				default:
					System.out.println("Invalid choice");
					break;
				}
			}break;
			
		case 4:
			tvmenu=false;
			break;
			
		case 5:
			System.exit(0);
			break;
		
			default:
			System.out.println("Invalid choice");
			break;
			

}
	}
	}
}

