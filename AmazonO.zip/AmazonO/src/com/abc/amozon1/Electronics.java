package com.abc.amozon1;

import java.util.Scanner;

public class Electronics {
	
	public static void electronics()
	{	
		boolean electronicmenu=true;
		while(electronicmenu)
		{
		Scanner scan=new Scanner(System.in);
		System.out.println("Welcome to Electronics\nChoose Category\n1.Mobiles\n2.TV\n3.Laptops\n4.Speakers\n5.Cart\n6.Back to Previous\n7.Exit");
		int electronicchoice=scan.nextInt();
		switch(electronicchoice)
		{
		case 1:
			new Mobiles().mobiles();
			break;
		
		case 2:
			new Tv().tv();
			break;
			
		case 3:
			new Laptop().laptop();;
			break;
		
		case 4:
			new Speakers().speakers();;
			break;
			
		case 5:
			new Cart().disp();
			break;
		
		case 6:
			electronicmenu=false;
			break;
		
		case 7:
			System.out.println("Thank U!!! Please Visit Again");
			System.exit(0);
			break;
			
		default:
			System.out.println("Invalid Choice");
			break;
		}
		}
	}

}
