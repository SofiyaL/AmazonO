package com.abc.amozon1;


import java.util.Scanner;

public class MensWear {
		
		public static void menswear()
		{
				boolean menswearmenu=true;
				boolean topwearmenu;
				boolean bottomwearmenu;
				boolean sportsmenu;
			while(menswearmenu)
			{
				Scanner scan=new Scanner(System.in);
				System.out.println("Please choose Category \n1.Topwear\n2.BottomWear\n3.SportsWear\n4.Back to Previous Menu\n5.Exit");
				int menswearoption=scan.nextInt();
				switch(menswearoption)
				{
				case 1:
				topwearmenu=true;
				while(topwearmenu)
				{
					System.out.println("Please select product from below list");
					System.out.printf("%-5s %-30s %-2s %s\n","S.NO","Product",":","Price");
					System.out.printf("%-5s %-30s %-2s %s\n","1","Superdry Round Neck T-shirt",":","999");
					System.out.printf("%-5s %-30s %-2s %s\n","2","Arrow Regular Fit Men Formal",":","1,999");
					System.out.printf("%-5s %-30s %-2s %s\n","3","Roadster Men Checked Jacket",":","2,500");
					System.out.println("4 Back to previous menu");
					int topwearchoice=scan.nextInt();
					switch(topwearchoice)
					{
					case 1:
						String superdry="Superdry Round Necc T-shirt";
						int superdryPrice=999;
						System.out.println("Enter Quantity");
						int superdryq=scan.nextInt();
						new Cart().cart(superdry, superdryq);
						new Cart().price(superdry, superdryPrice);
						System.out.println("Superdry Round Necc T-shirt added to Shopping Cart");
						System.out.println("**********************");
						break;
					
					case 2:
						String arrow="Arrow Grey Regular Fit Men Formal";
						int arrowPrice=1999;
						System.out.println("Enter Quantity");
						int  arrowq=scan.nextInt();
						new Cart().cart( arrow,  arrowq);
						new Cart().price( arrow,  arrowPrice);
						System.out.println("Arrow Regular Fit Men Formal added to Shopping Cart");
						break;
					
					case 3:
						String roadster="Roadster Men Checked Jacket";
						int roadsterPrice=9990;
						System.out.println("Enter Quantity");
						int  roadsterq=scan.nextInt();
						new Cart().cart( roadster,  roadsterq);
						new Cart().price( roadster,  roadsterPrice);
						System.out.println("Roadster Men Checked Jacket added to Shopping Cart");
						break;
					
					case 4:
					topwearmenu=false;
					break;
					
					default:
						System.out.println("Invalid choice");
						break;
					}
				}break;
				
				case 2:
					bottomwearmenu=true;
					while(bottomwearmenu)
					{
						System.out.println("Please select Product from below list");
						System.out.printf("%-5s %-30s %-2s %s\n","S.NO","Product",":","Price");
						System.out.printf("%-5s %-30s %-2s %s\n","1","Spykar Skinny Fit Jeans",":","1,499");
						System.out.printf("%-5s %-30s %-2s %s\n","2","Puma Regular Fit Short",":","899");
						System.out.printf("%-5s %-30s %-2s %s\n","3","Louis Pilippe Formal Trouser",":","2,199");
						System.out.println("4.Back to previous menu");
						int bottomwearchoice=scan.nextInt();
						switch(bottomwearchoice)
						{
						case 1:
							String spykar="Spykar Skinny Fit Jeans";
							int spykarPrice=1499;
							System.out.println("Enter Quantity");
							int  spykarq=scan.nextInt();
							new Cart().cart( spykar,  spykarq);
							new Cart().price( spykar,  spykarPrice);
							System.out.println("Spykar Skinny Fit Jeans added to Shopping Cart");
							System.out.println("**********************");
							break;
						
						case 2:
							String puma="Puma Regular Fit Short";
							int pumaPrice=899;
							System.out.println("Enter Quantity");
							int  pumaq=scan.nextInt();
							new Cart().cart( puma,  pumaq);
							new Cart().price( puma,  pumaPrice);
							System.out.println("Puma Regular Fit Short added to Shopping Cart");
							System.out.println("**********************");
							break;
						
						case 3:
							String louisphilip="Louis Pilippe Formal Trouser";
							int louisphilipPrice=2199;
							System.out.println("Enter Quantity");
							int  louisphilipq=scan.nextInt();
							new Cart().cart( louisphilip,  louisphilipq);
							new Cart().price( louisphilip,  louisphilipPrice);
							System.out.println("Louis Pilippe Formal Trouser added to Shopping Cart");
							System.out.println("**********************");
							break;
						
						case 4:
						bottomwearmenu=false;
						break;
						
						default:
							System.out.println("Invalid choice");
							break;
						}
					}break;
					
				case 3:
					sportsmenu=true;
					while(sportsmenu)
					{
						System.out.println("Please select product from below list");
						System.out.printf("%-5s %-30s %-2s %s\n","S.NO","Product",":","Price");
						System.out.printf("%-5s %-30s %-2s %s\n","1","Nike Men Blue Tracksuit",":","1,999");
						System.out.printf("%-5s %-30s %-2s %s\n","2","Adidas sports jacket",":","3,599");
						System.out.printf("%-5s %-30s %-2s %s\n","3","HRX Black Track Pant",":","799");
						System.out.println("4 Back to previous menu");
						int sportschoice=scan.nextInt();
						switch(sportschoice)
						{
						case 1:
							String nike="Nike Men Blue Tracksuit";
							int nikePrice=1999;
							System.out.println("Enter Quantity");
							int  nikeq=scan.nextInt();
							new Cart().cart( nike,  nikeq);
							new Cart().price( nike,  nikePrice);
							System.out.println("Nike Men Blue Tracksuit added to Shopping Cart");
							System.out.println("**********************");
							break;
						
						case 2:
							String adidas="Adidas sports jacket";
							int adidasPrice=3599;
							System.out.println("Enter Quantity");
							int  adidasq=scan.nextInt();
							new Cart().cart( adidas,  adidasq);
							new Cart().price( adidas,  adidasPrice);
							System.out.println("Adidas sports jacket added to Shopping Cart");
							System.out.println("**********************");
							break;
						
						case 3:
							String hrx="HRX Black Track Pant";
							int hrxPrice=799;
							System.out.println("Enter Quantity");
							int  hrxq=scan.nextInt();
							new Cart().cart( hrx,  hrxq);
							new Cart().price( hrx,  hrxPrice);
							System.out.println("HRX Black Track Pant added to Shopping Cart");
							System.out.println("**********************");
							break;
						
						case 4:
						sportsmenu=false;
						break;
						
						default:
							System.out.println("Invalid choice");
							break;
						}
					}break;
					
				case 4:
					menswearmenu=false;
					break;
					
				case 5:
					System.exit(0);
					break;
				
					default:
					System.out.println("Invalid choice");
					break;
					

		}
			}
		}
	}


