package com.abc.amozon1;

import java.util.Scanner;

public class Groceries {
	
	public static void groceries()
	{
		boolean groceriesmenu=true;
		while(groceriesmenu)
		{
		Scanner scan=new Scanner(System.in);
		System.out.println("Welcome to Groceries Store\nChoose Category\n1.Foodgrains & oils\n2.Cleaning household\n3.Back to Previous\n4.Exit");
		int grocerieschoice=scan.nextInt();
		switch(grocerieschoice)
		{
		case 1:
			new Eatables().foodgrainsOils();
			break;
		
		case 2:
			new HouseItems().cleaningousehold();
			break;
		
		case 3:
			groceriesmenu=false;
			break;
		
		case 4:
			System.out.println("Thank U!!! Please Visit Again");
			System.exit(0);
			break;
			
		default:
			System.out.println("Invalid Choice");
			break;
		}
		}
	}
}
