package com.abc.amozon1;

import java.util.Scanner;

public class Mobiles {
	
	public static void mobiles()
	{
		boolean mobilemenu=true;
		boolean samsungmenu;
		boolean oneplusmenu;
		boolean applemenu;
	while(mobilemenu)
	{
		Scanner scan=new Scanner(System.in);
		System.out.println("Please choose mobile Brand \n1.Samsung\n2.Oneplus\n3.Apple\n4.Back to Previous Menu\n5.Exit");
		int mobileoption=scan.nextInt();
		switch(mobileoption)
		{
		case 1:
		samsungmenu=true;
		while(samsungmenu)
		{
			System.out.println("Please select Model from below list");
			System.out.printf("%-5s %-7s %-2s %s\n","S.NO","Model",":","Price");
			System.out.printf("%-5s %-7s %-2s %s\n","1","Note 8",":","39990");
			System.out.printf("%-5s %-7s %-2s %s\n","2","A70",":","19990");
			System.out.printf("%-5s %-7s %-2s %s\n","3","M20",":","9990");
			System.out.println("4 Back to previous menu");
			int samsungmodel=scan.nextInt();
			switch(samsungmodel)
			{
			case 1:
				String note8="Note 8";
				int note8Price=39990;
				System.out.println("Enter Quantity");
				int note8q=scan.nextInt();
				new Cart().cart(note8, note8q);
				new Cart().price(note8, note8Price);
				System.out.println("Samsung Note 8 added to Shopping Cart");
				System.out.println("**********************");
				break;
			
			case 2:
				String A70="Note 8";
				int A70Price=19990;
				System.out.println("Enter Quantity");
				int A70q=scan.nextInt();
				new Cart().cart(A70, A70q);
				new Cart().price(A70,A70Price);
				System.out.println("Samsung A70 added to Shopping Cart");
				break;
			
			case 3:
				String M20="Note 8";
				int M20Price=9990;
				System.out.println("Enter Quantity");
				int M20q=scan.nextInt();
				new Cart().cart(M20, M20q);
				new Cart().price(M20, M20Price);
				System.out.println("Samsung A70 added to Shopping Cart");
				break;
			
			case 4:
			samsungmenu=false;
			break;
			
			default:
				System.out.println("Invalid choice");
				break;
			}
		}break;
		
		case 2:
			oneplusmenu=true;
			while(oneplusmenu)
			{
				System.out.println("Please select Model from below list");
				System.out.printf("%-5s %-14s %-2s %s\n","S.NO","Model",":","Price");
				System.out.printf("%-5s %-14s %-2s %s\n","1","OnePlus 7T",":","39990");
				System.out.printf("%-5s %-14s %-2s %s\n","2","OnePlus 7",":","29990");
				System.out.printf("%-5s %-14s %-2s %s\n","3","OnePlus 7 Pro",":","48990");
				System.out.println("4.Back to previous menu");
				int oneplusmodel=scan.nextInt();
				switch(oneplusmodel)
				{
				case 1:
					String op7t="OnePlus 7T";
					int op7tPrice=39990;
					System.out.println("Enter Quantity");
					int op7tq=scan.nextInt();
					new Cart().cart(op7t, op7tq);
					new Cart().price(op7t, op7tPrice);
					System.out.println("Oneplus 7T added to Shopping Cart");
					System.out.println("**********************");
					break;
				
				case 2:
					String op7="OnePlus 7";
					int op7Price=29990;
					System.out.println("Enter Quantity");
					int op7q=scan.nextInt();
					new Cart().cart(op7, op7q);
					new Cart().price(op7, op7Price);
					System.out.println("Oneplus 7 added to Shopping Cart");
					System.out.println("**********************");
					break;
				
				case 3:
					String op7pro="OnePlus 7 Pro";
					int op7proPrice=48990;
					System.out.println("Enter Quantity");
					int op7proq=scan.nextInt();
					new Cart().cart(op7pro, op7proq);
					new Cart().price(op7pro, op7proPrice);
					System.out.println("OnePlus 7Pro added to Shopping Cart");
					System.out.println("**********************");
					break;
				
				case 4:
				oneplusmenu=false;
				break;
				
				default:
					System.out.println("Invalid choice");
					break;
				}
			}break;
			
		case 3:
			applemenu=true;
			while(applemenu)
			{
				System.out.println("Please select Model from below list");
				System.out.printf("%-5s %-12s %-2s %s\n","S.NO","Model",":","Price");
				System.out.printf("%-5s %-12s %-2s %s\n","1","Iphone XR",":","45900");
				System.out.printf("%-5s %-12s %-2s %s\n","2","Iphone 11",":","69900");
				System.out.printf("%-5s %-12s %-2s %s\n","3","Iphone 11 Pro",":","99900");
				System.out.println("4 Back to previous menu");
				int applemodel=scan.nextInt();
				switch(applemodel)
				{
				case 1:
					String iphonexr="Iphone XR";
					int iphonexrPrice=45900;
					System.out.println("Enter Quantity");
					int iphonexrq=scan.nextInt();
					new Cart().cart(iphonexr, iphonexrq);
					new Cart().price(iphonexr, iphonexrPrice);
					System.out.println("Iphone XR added to Shopping Cart");
					System.out.println("**********************");
					break;
				
				case 2:
					String iphone11="Iphone 11";
					int iphone11Price=69900;
					System.out.println("Enter Quantity");
					int iphone11q=scan.nextInt();
					new Cart().cart( iphone11,  iphone11q);
					new Cart().price( iphone11,  iphone11Price);
					System.out.println("Iphone 11 added to Shopping Cart");
					System.out.println("**********************");
					break;
				
				case 3:
					String iphone11pro="Iphone 11 Pro";
					int iphone11proPrice=99900;
					System.out.println("Enter Quantity");
					int iphone11proq=scan.nextInt();
					new Cart().cart( iphone11pro,  iphone11proq);
					new Cart().price( iphone11pro,  iphone11proPrice);
					System.out.println("Iphone 11 Pro added to Shopping Cart");
					System.out.println("**********************");
					break;
				
				case 4:
				applemenu=false;
				break;
				
				default:
					System.out.println("Invalid choice");
					break;
				}
			}break;
			
		case 4:
			mobilemenu=false;
			break;
			
		case 5:
			System.exit(0);
			break;
		
			default:
			System.out.println("Invalid choice");
			break;
			

}
	}
}
}
