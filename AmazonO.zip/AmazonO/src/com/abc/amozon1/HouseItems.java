package com.abc.amozon1;

import java.util.Scanner;

public class HouseItems {
	
	public static void cleaningousehold()
	{
		boolean cleaninghouseholdmenu=true;
		boolean detergentmenu;
		boolean freshenersmenu;
		boolean mopsmenu;
	while(cleaninghouseholdmenu)
	{
		Scanner scan=new Scanner(System.in);
		System.out.println("Please choose Category \n1.Detergents | Dishwash\n2.Repellents | Fresheners\n3.Mops | Brushes | Scrubs\n4.Back to Previous Menu\n5.Exit");
		int menswearoption=scan.nextInt();
		switch(menswearoption)
		{
		case 1:
		detergentmenu=true;
		while(detergentmenu)
		{
			System.out.println("Please select product from below list");
			System.out.printf("%-5s %-30s %-2s %s\n","S.NO","Product",":","Price");
			System.out.printf("%-5s %-30s %-2s %s\n","1","Vim Dishwash Gel 1.8L",":","316");
			System.out.printf("%-5s %-30s %-2s %s\n","2","Surf Excel Matic 2Kg",":","376");
			System.out.printf("%-5s %-30s %-2s %s\n","3","Comfort After Wash",":","200");
			System.out.println("4 Back to previous menu");
			int detergentchoice=scan.nextInt();
			switch(detergentchoice)
			{
			case 1:
				String detergent1="Vim Dishwash Gel 1.8L";
				int detergent1Price=316;
				System.out.println("Enter Quantity");
				int  detergent1q=scan.nextInt();
				new Cart().cart( detergent1,  detergent1q);
				new Cart().price( detergent1,  detergent1Price);
				System.out.println("Vim Dishwash Gel 1.8L added to Shopping Cart");
				System.out.println("**********************");
				break;
			
			case 2:
				String detergent2="Surf Excel Matic 2Kg";
				int detergent2Price=376;
				System.out.println("Enter Quantity");
				int  detergent2q=scan.nextInt();
				new Cart().cart( detergent2,  detergent2q);
				new Cart().price( detergent2,  detergent2Price);
				System.out.println("Surf Excel Matic 2Kg added to Shopping Cart");
				break;
			
			case 3:
				String detergent3="Comfort After Wash";
				int detergent3Price=200;
				System.out.println("Enter Quantity");
				int  detergent3q=scan.nextInt();
				new Cart().cart( detergent3,  detergent3q);
				new Cart().price( detergent3,  detergent3Price);
				System.out.println("Comfort After Wash added to Shopping Cart");
				break;
			
			case 4:
			detergentmenu=false;
			break;
			
			default:
				System.out.println("Invalid choice");
				break;
			}
		}break;
		
		case 2:
			freshenersmenu=true;
			while(freshenersmenu)
			{
				System.out.println("Please select Product from below list");
				System.out.printf("%-5s %-30s %-2s %s\n","S.NO","Product",":","Price");
				System.out.printf("%-5s %-30s %-2s %s\n","1","Godrej Aer Pocket Freshner",":","200");
				System.out.printf("%-5s %-30s %-2s %s\n","2","Hit Insect Killer",":","160");
				System.out.printf("%-5s %-30s %-2s %s\n","3","Good Knight power pack2",":","140");
				System.out.println("4.Back to previous menu");
				int freshenerschoice=scan.nextInt();
				switch(freshenerschoice)
				{
				case 1:
					String fresheners1="Godrej Aer Pocket Freshner";
					int fresheners1Price=200;
					System.out.println("Enter Quantity");
					int  fresheners1q=scan.nextInt();
					new Cart().cart( fresheners1,  fresheners1q);
					new Cart().price(fresheners1,  fresheners1Price);
					System.out.println("Godrej Aer Pocket Freshner added to Shopping Cart");
					System.out.println("**********************");
					break;
				
				case 2:
					String fresheners2="Hit Insect Killer";
					int fresheners2Price=160;
					System.out.println("Enter Quantity");
					int  fresheners2q=scan.nextInt();
					new Cart().cart( fresheners2,  fresheners2q);
					new Cart().price(fresheners2,  fresheners2Price);
					System.out.println("Hit Insect Killer added to Shopping Cart");
					System.out.println("**********************");
					break;
				
				case 3:
					String fresheners3="Good Knight power pack2";
					int fresheners3Price=140;
					System.out.println("Enter Quantity");
					int  fresheners3q=scan.nextInt();
					new Cart().cart( fresheners3,  fresheners3q);
					new Cart().price(fresheners3,  fresheners3Price);
					System.out.println("Good Knight power pack2 added to Shopping Cart");
					System.out.println("**********************");
					break;
				
				case 4:
				freshenersmenu=false;
				break;
				
				default:
					System.out.println("Invalid choice");
					break;
				}
			}break;
			
		case 3:
			mopsmenu=true;
			while(mopsmenu)
			{
				System.out.println("Please select product from below list");
				System.out.printf("%-5s %-30s %-2s %s\n","S.NO","Product",":","Price");
				System.out.printf("%-5s %-30s %-2s %s\n","1","Lizol Surface Cleaner",":","189");
				System.out.printf("%-5s %-30s %-2s %s\n","2","BB 360 Degree spin Mop",":","549");
				System.out.printf("%-5s %-30s %-2s %s\n","3","Colin Cleaner 500ml",":","150");
				System.out.println("4 Back to previous menu");
				int mopschoice=scan.nextInt();
				switch(mopschoice)
				{
				case 1:
					String mops1="Lizol Surface Cleaner";
					int mops1Price=189;
					System.out.println("Enter Quantity");
					int  mops1q=scan.nextInt();
					new Cart().cart( mops1,  mops1q);
					new Cart().price(mops1,  mops1Price);
					System.out.println("Lizol Surface Cleaner added to Shopping Cart");
					System.out.println("**********************");
					break;
				
				case 2:
					String mops2="BB 360 Degree spin Mop";
					int mops2Price=549;
					System.out.println("Enter Quantity");
					int  mops2q=scan.nextInt();
					new Cart().cart( mops2,  mops2q);
					new Cart().price(mops2,  mops2Price);
					System.out.println("BB 360 Degree spin Mop added to Shopping Cart");
					System.out.println("**********************");
					break;
				
				case 3:
					String mops3="Colin Cleaner 500ml";
					int mops3Price=150;
					System.out.println("Enter Quantity");
					int  mops3q=scan.nextInt();
					new Cart().cart( mops3,  mops3q);
					new Cart().price(mops3,  mops3Price);
					System.out.println("Colin Cleaner 500ml added to Shopping Cart");
					System.out.println("**********************");
					break;
				
				case 4:
				mopsmenu=false;
				break;
				
				default:
					System.out.println("Invalid choice");
					break;
				}
			}break;
			
		case 4:
			cleaninghouseholdmenu=false;
			break;
			
		case 5:
			System.exit(0);
			break;
		
			default:
			System.out.println("Invalid choice");
			break;
			

}
	}
	}

}
