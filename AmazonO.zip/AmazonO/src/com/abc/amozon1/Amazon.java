package com.abc.amozon1;


import java.util.InputMismatchException;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

class nameMatch extends Exception
{
	public String toString()
	{
		return "Not a valid name";
	}
}

public class Amazon {

	public static void main(String[] args) {

		Amazon ao=new Amazon();
		ao.shopping();
	}
	public static void shopping()
	{
		boolean categorymenu=true;
		boolean electronicsmenu;
		boolean mobilemenu;
		boolean samsungmenu;
		while(categorymenu)
		{
			System.out.println("*************************************");
			System.out.printf("%20s %n",     "Amazon"                 );
			System.out.println("*************************************");
			System.out.println("Enter your Name");
			Scanner scan=new Scanner(System.in);
			String name=scan.nextLine();
			String s="[a-zA-Z]+\\.?";
			boolean b=name.matches(s);
			if(b!=true)
			{
				try {
					throw new nameMatch();
				} catch (nameMatch e) {
					System.out.println("Not a valid name");
				}
			}
			else
			{
				try {
					System.out.println("Hello"+" "+name+" Welcome to amazon!!!!");
					while(categorymenu)	
					{
						System.out.println("Shop by Category\n1.Electronics\n2.Clothing\n3.Groceries\n4.Sports\n5.Cart\n6.Exit");
						int categoryOption=scan.nextInt();
						switch(categoryOption)
						{
						case 1:
							new Electronics().electronics();
							break;
						case 2:
							new Clothing().clothing();
							break;
						case 3:
							new Groceries().groceries();;
							break;

						case 4:
							new Sports().sports();
							break;

						case 5:
							new Cart().disp();
							break;

						case 6:
							System.out.println("Thankuuuuuu.... Please Visit Us Again!!!");
							System.exit(0);

						default:
							System.out.println("Invalid Choice");
							break;
						}
					}
				}
				catch(InputMismatchException e)
				{
					System.out.println("Please provide valid input");
				}
				
			}

		}
	}
}



