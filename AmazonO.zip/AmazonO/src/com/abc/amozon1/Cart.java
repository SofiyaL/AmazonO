package com.abc.amozon1;

import java.util.HashMap;
import java.util.Map.Entry;
import java.util.Scanner;

public class Cart {
	static HashMap<String,Integer> hm=new HashMap<String, Integer>();
	static HashMap<String,Integer> hp=new HashMap<String, Integer>();
	private static int total;

	public static void cart(String name,int quantity) {

		if(hm.containsKey(name)) {
			hm.put(name, hm.get(name)+quantity);
		}
		else {
			hm.put(name, quantity);
		}
	}



	static void price(String name,int price) {
		System.out.println("     ----MY  CART-----   ");
		if(hp.containsKey(name)) {

		}
		else {
			hp.put(name, price);
		}


		
	}



	private static void edit() {
		
		
		for(Entry<String, Integer> v: hm.entrySet()) {
			System.out.format("%-46s  %s\n",v.getKey(),v.getValue());
			
			
		}
		System.out.println("enter item  name to edit");
		Scanner sc = new Scanner(System.in);
		String line = sc.nextLine();
		System.out.println("enter new Quantity");
		int up = sc.nextInt();
		if(up!=0) {
		hm.put(line, up);
		disp();
		}
		else {
			hm.remove(line);
			hp.remove(line);
			disp();
		}
		
		

	}



	public static void disp() {
		int i=1;
		System.out.format("%-5s %-15s %-15s %-10s %s\n","s.no","product","Quantity"," price","total"); 

		for(Entry<String, Integer> v: hm.entrySet()) {
			Integer defaultValue = null;
			System.out.format("%-5s %-15s %-15s %-10s %s\n",i,v.getKey(),v.getValue(), hp.getOrDefault(v.getKey(), defaultValue),( v.getValue()*(hp.getOrDefault(v.getKey(), defaultValue)))); 
			//System.out.println(+"   " ++"   "++"  "++"  "+);
			i++;
			total+=v.getValue()*(hp.getOrDefault(v.getKey(), defaultValue));
		}

		System.out.println("===========================================================");
		System.out.format("%-46s  %s\n","cart value",total); 
		System.out.format("%-46s  %s\n","CGST 8%",total*0.08); 
		System.out.format("%-46s  %s\n","SGST 7%",total*0.07); 
		System.out.format("%-46s  %s\n","Net amount",total*0.07+total*0.08+total); 
		System.out.println("===========================================================");
		System.out.println();
		total=0;
		
		System.out.println("Do you want to edit your cart");
		System.out.println("1.  yes");
		System.out.println("2. no");
		Scanner scn = new Scanner(System.in);
		int s1 = scn.nextInt();
		if(s1==1) {
			edit();
		}
		else {

			System.out.println("==********==");
			System.out.println("Do you want to continue shopping");
			System.out.println("1.  yes");
			System.out.println("2. no");

			int s = scn.nextInt();
			if(s==1) {
				new Amazon().shopping();
			}
			else {
				System.out.println("-----Thank you-------");
				System.exit(0);
			}
		}
		
	}
	public static void exitdisp() {
		int i=1;
		System.out.format("%-5s %-15s %-15s %-10s %s\n","s.no","product","Quantity"," price","total"); 

		for(Entry<String, Integer> v: hm.entrySet()) {
			Integer defaultValue = null;
			System.out.format("%-5s %-15s %-13s %-10s %s\n",i,v.getKey(),v.getValue(), hp.getOrDefault(v.getKey(), defaultValue),( v.getValue()*(hp.getOrDefault(v.getKey(), defaultValue)))); 
			//System.out.println(+"   " ++"   "++"  "++"  "+);
			i++;
			total+=v.getValue()*(hp.getOrDefault(v.getKey(), defaultValue));
		}

		System.out.println("===========================================================");
		System.out.format("%-46s  %s\n","cart value",total); 
		System.out.format("%-46s  %s\n","CGST 8%",total*0.08); 
		System.out.format("%-46s  %s\n","SGST 7%",total*0.07); 
		System.out.format("%-46s  %s\n","Net amount",total*0.07+total*0.08+total); 
		System.out.println("===========================================================");
		System.out.println();
		total=0;
		
	}
}



