package com.abc.amozon1;


import java.util.Scanner;

public class Speakers {

	public static void speakers()
	{

		boolean speakersmenu=true;
		boolean bosemenu;
		boolean sonymenu;
		boolean fdmenu;
	while(speakersmenu)
	{
		Scanner scan=new Scanner(System.in);
		System.out.println("Please choose Speakers Brand \n1.Bose\n2.Sony\n3.F&D\n4.Back to Previous Menu\n5.Exit");
		int mobileoption=scan.nextInt();
		switch(mobileoption)
		{
		case 1:
		bosemenu=true;
		while(bosemenu)
		{
			System.out.println("Please select Model from below list");
			System.out.printf("%-5s %-15s %-2s %s\n","S.NO","Model",":","Price");
			System.out.printf("%-5s %-15s %-2s %s\n","1","SoundLink Mini",":","12,960");
			System.out.printf("%-5s %-15s %-2s %s\n","2","SoundLink Micro",":","8,990");
			System.out.printf("%-5s %-15s %-2s %s\n","3","SoundTouch20",":","33,600");
			System.out.println("4 : Back to previous menu");
			int bosemodel=scan.nextInt();
			switch(bosemodel)
			{
			case 1:
				String soundmini="Bose SoundLink Mini";
				int soundminiPrice=12960;
				System.out.println("Enter Quantity");
				int soundminiq=scan.nextInt();
				new Cart().cart(soundmini, soundminiq);
				new Cart().price(soundmini, soundminiPrice);
				System.out.println("Bose SoundLink Mini added to Shopping Cart");
				System.out.println("**********************");
				break;
			
			case 2:
				String soundmicro="Bose SoundLink Micro";
				int soundmicroPrice=8990;
				System.out.println("Enter Quantity");
				int soundmicroq=scan.nextInt();
				new Cart().cart(soundmicro, soundmicroq);
				new Cart().price(soundmicro, soundmicroPrice);
				System.out.println("Bose SoundLink Mini added to Shopping Cart");
				System.out.println("**********************");
				break;
			
			case 3:
				String soundtouch="Bose SoundTouch20";
				int soundtouchPrice=33600;
				System.out.println("Enter Quantity");
				int soundtouchq=scan.nextInt();
				new Cart().cart(soundtouch, soundtouchq);
				new Cart().price(soundtouch, soundtouchPrice);
				System.out.println("Bose SoundLink Touch 20 added to Shopping Cart");
				System.out.println("**********************");
				break;
			
			case 4:
			bosemenu=false;
			break;
			
			default:
				System.out.println("Invalid choice");
				break;
			}
		}break;
		
		case 2:
			sonymenu=true;
			while(sonymenu)
			{
				System.out.println("Please select Model from below list");
				System.out.printf("%-5s %-14s %-2s %s\n","S.NO","Model",":","Price");
				System.out.printf("%-5s %-14s %-2s %s\n","1","SA-D40",":","8,190");
				System.out.printf("%-5s %-14s %-2s %s\n","2","HT-RT40",":","21,990");
				System.out.printf("%-5s %-14s %-2s %s\n","3","HT-RT3",":","17,990");
				System.out.println("4.Back to previous menu");
				int sonymodel=scan.nextInt();
				switch(sonymodel)
				{
				case 1:
					String sony1="Sony SA-D40";
					int sony1Price=8190;
					System.out.println("Enter Quantity");
					int sony1q=scan.nextInt();
					new Cart().cart(sony1, sony1q);
					new Cart().price(sony1, sony1Price);
					System.out.println("Sony SA-D40 added to Shopping Cart");
					System.out.println("**********************");
					break;
				
				case 2:
					String sony2="HT-RT40";
					int sony2Price=21990;
					System.out.println("Enter Quantity");
					int sony2q=scan.nextInt();
					new Cart().cart(sony2, sony2q);
					new Cart().price(sony2, sony2Price);
					System.out.println("Sony HT-RT40 added to Shopping Cart");
					System.out.println("**********************");
					break;
				
				case 3:
					String sony3="";
					int sony3Price=17990;
					System.out.println("Enter Quantity");
					int sony3q=scan.nextInt();
					new Cart().cart(sony3, sony3q);
					new Cart().price(sony3, sony3Price);
					System.out.println("Sony HT-RT3 added to Shopping Cart");
					System.out.println("**********************");
					break;
				
				case 4:
				sonymenu=false;
				break;
				
				default:
					System.out.println("Invalid choice");
					break;
				}
			}break;
			
		case 3:
			fdmenu=true;
			while(fdmenu)
			{
				System.out.println("Please select Model from below list");
				System.out.printf("%-5s %-7s %-2s %s\n","S.NO","Model",":","Price");
				System.out.printf("%-5s %-7s %-2s %s\n","1","A180X",":","2,899");
				System.out.printf("%-5s %-7s %-2s %s\n","2","F3800X",":","5,499");
				System.out.printf("%-5s %-7s %-2s %s\n","3","F5060X",":","9,999");
				System.out.println("4 Back to previous menu");
				int fdmodel=scan.nextInt();
				switch(fdmodel)
				{
				case 1:
					String fd1="A180X";
					int fd1Price=2899;
					System.out.println("Enter Quantity");
					int fd1q=scan.nextInt();
					new Cart().cart(fd1, fd1q);
					new Cart().price(fd1, fd1Price);
					System.out.println("F&D A180X added to Shopping Cart");
					System.out.println("**********************");
					break;
				
				case 2:
					String fd2="F3800X";
					int fd2Price=5499;
					System.out.println("Enter Quantity");
					int fd2q=scan.nextInt();
					new Cart().cart(fd2, fd2q);
					new Cart().price(fd2, fd2Price);
					System.out.println("F&D F3800X added to Shopping Cart");
					System.out.println("**********************");
					break;
				
				case 3:
					String fd3="F5060X";
					int fd3Price=9999;
					System.out.println("Enter Quantity");
					int fd3q=scan.nextInt();
					new Cart().cart(fd3, fd3q);
					new Cart().price(fd3, fd3Price);
					System.out.println("F&D F5060X added to Shopping Cart");
					System.out.println("**********************");
					break;
				
				case 4:
				fdmenu=false;
				break;
				
				default:
					System.out.println("Invalid choice");
					break;
				}
			}break;
			
		case 4:
			speakersmenu=false;
			break;
			
		case 5:
			System.exit(0);
			break;
		
			default:
			System.out.println("Invalid choice");
			break;
			

}
	}
	}
}

