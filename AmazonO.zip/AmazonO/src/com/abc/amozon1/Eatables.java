package com.abc.amozon1;

import java.util.Scanner;

public class Eatables {
	
	public static void foodgrainsOils()
	{
		boolean foodgrainsmenu=true;
		boolean flourmenu;
		boolean oilgheemenu;
		boolean dryfruitsmenu;
	while(foodgrainsmenu)
	{
		Scanner scan=new Scanner(System.in);
		System.out.println("Please choose Category \n1.Flour\n2.Oil & Ghee\n3.Dry Fruits\n4.Back to Previous Menu\n5.Exit");
		int menswearoption=scan.nextInt();
		switch(menswearoption)
		{
		case 1:
		flourmenu=true;
		while(flourmenu)
		{
			System.out.println("Please select product from below list");
			System.out.printf("%-5s %-30s %-2s %s\n","S.NO","Product",":","Price");
			System.out.printf("%-5s %-30s %-2s %s\n","1","Aashirvaad Whole Wheat 5Kg",":","384");
			System.out.printf("%-5s %-30s %-2s %s\n","2","Patanjali Chakki Atta 2kg",":","120");
			System.out.printf("%-5s %-30s %-2s %s\n","3","Pillsbury chakki fresh Atta",":","400");
			System.out.println("4 Back to previous menu");
			int flourchoice=scan.nextInt();
			switch(flourchoice)
			{
			case 1:
				String flour1="Aashirvaad Whole Wheat 5Kg";
				int flour1Price=384;
				System.out.println("Enter Quantity");
				int  flour1q=scan.nextInt();
				new Cart().cart( flour1,  flour1q);
				new Cart().price( flour1,  flour1Price);
				System.out.println("Aashirvaad Whole Wheat 5Kg added to Shopping Cart");
				System.out.println("**********************");
				break;
			
			case 2:
				String flour2="Patanjali Chakki Atta 2kg";
				int flour2Price=120;
				System.out.println("Enter Quantity");
				int  flour2q=scan.nextInt();
				new Cart().cart( flour2,  flour2q);
				new Cart().price( flour2,  flour2Price);
				System.out.println("Patanjali Chakki Atta 2kg added to Shopping Cart");
				break;
			
			case 3:
				String flour3="Pillsbury chakki fresh Atta";
				int flour3Price=400;
				System.out.println("Enter Quantity");
				int  flour3q=scan.nextInt();
				new Cart().cart( flour3,  flour3q);
				new Cart().price( flour3,  flour3Price);
				System.out.println("Pillsbury chakki fresh Atta added to Shopping Cart");
				break;
			
			case 4:
			flourmenu=false;
			break;
			
			default:
				System.out.println("Invalid choice");
				break;
			}
		}break;
		
		case 2:
			oilgheemenu=true;
			while(oilgheemenu)
			{
				System.out.println("Please select Product from below list");
				System.out.printf("%-5s %-30s %-2s %s\n","S.NO","Product",":","Price");
				System.out.printf("%-5s %-30s %-2s %s\n","1","Nandini Pure cow ghee 1L",":","450");
				System.out.printf("%-5s %-30s %-2s %s\n","2","Fortune Sunflower Oil 1L",":","99");
				System.out.printf("%-5s %-30s %-2s %s\n","3","Del Monte Olive Oil 1L",":","499");
				System.out.println("4.Back to previous menu");
				int oilgheechoice=scan.nextInt();
				switch(oilgheechoice)
				{
				case 1:
					String oilghee1="Nandini Pure cow ghee 1L";
					int oilghee1Price=450;
					System.out.println("Enter Quantity");
					int  oilghee1q=scan.nextInt();
					new Cart().cart( oilghee1,  oilghee1q);
					new Cart().price( oilghee1,  oilghee1Price);
					System.out.println("Nandini Pure cow ghee 1L added to Shopping Cart");
					System.out.println("**********************");
					break;
				
				case 2:
					String oilghee2="Fortune Sunflower Oil 1L";
					int oilghee2Price=99;
					System.out.println("Enter Quantity");
					int  oilghee2q=scan.nextInt();
					new Cart().cart( oilghee2,  oilghee2q);
					new Cart().price( oilghee2,  oilghee2Price);
					System.out.println("Fortune Sunflower Oil 1L added to Shopping Cart");
					System.out.println("**********************");
					break;
				
				case 3:
					String oilghee3="Del Monte Olive Oil 1L";
					int oilghee3Price=499;
					System.out.println("Enter Quantity");
					int  oilghee3q=scan.nextInt();
					new Cart().cart( oilghee3,  oilghee3q);
					new Cart().price( oilghee3,  oilghee3Price);
					System.out.println("Del Monte Olive Oil 1L added to Shopping Cart");
					System.out.println("**********************");
					break;
				
				case 4:
				oilgheemenu=false;
				break;
				
				default:
					System.out.println("Invalid choice");
					break;
				}
			}break;
			
		case 3:
			dryfruitsmenu=true;
			while(dryfruitsmenu)
			{
				System.out.println("Please select product from below list");
				System.out.printf("%-5s %-30s %-2s %s\n","S.NO","Product",":","Price");
				System.out.printf("%-5s %-30s %-2s %s\n","1","BB Cashews 1kg",":","1200");
				System.out.printf("%-5s %-30s %-2s %s\n","2","Califonia Walnuts 1kg",":","1900");
				System.out.printf("%-5s %-30s %-2s %s\n","3","BB Almonds 1kg",":","900");
				System.out.println("4 Back to previous menu");
				int dryfruitschoice=scan.nextInt();
				switch(dryfruitschoice)
				{
				case 1:
					String dryfruits1="BB Cashews 1kg";
					int dryfruits1Price=1200;
					System.out.println("Enter Quantity");
					int  dryfruits1q=scan.nextInt();
					new Cart().cart( dryfruits1,  dryfruits1q);
					new Cart().price( dryfruits1,  dryfruits1Price);
					System.out.println("BB Cashews 1kg added to Shopping Cart");
					System.out.println("**********************");
					break;
				
				case 2:
					String dryfruits2="Califonia Walnuts 1kg";
					int dryfruits2Price=1900;
					System.out.println("Enter Quantity");
					int  dryfruits2q=scan.nextInt();
					new Cart().cart( dryfruits2,  dryfruits2q);
					new Cart().price( dryfruits2,  dryfruits2Price);
					System.out.println("Califonia Walnuts 1kg added to Shopping Cart");
					System.out.println("**********************");
					break;
				
				case 3:
					String dryfruits3="BB Almonds 1kg";
					int dryfruits3Price=900;
					System.out.println("Enter Quantity");
					int  dryfruits3q=scan.nextInt();
					new Cart().cart( dryfruits3,  dryfruits3q);
					new Cart().price( dryfruits3,  dryfruits3Price);
					System.out.println("BB Almonds 1kg added to Shopping Cart");
					System.out.println("**********************");
					break;
				
				case 4:
				dryfruitsmenu=false;
				break;
				
				default:
					System.out.println("Invalid choice");
					break;
				}
			}break;
			
		case 4:
			foodgrainsmenu=false;
			break;
			
		case 5:
			System.exit(0);
			break;
		
			default:
			System.out.println("Invalid choice");
			break;
			

}
	}
	}

}
