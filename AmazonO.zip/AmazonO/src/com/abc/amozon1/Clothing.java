package com.abc.amozon1;

import java.util.Scanner;

public class Clothing {

	public static void clothing()
	{
		boolean clothingmenu=true;
		while(clothingmenu)
		{
		Scanner scan=new Scanner(System.in);
		System.out.println("Welcome to Clothing\nChoose Category\n1.Men's Wear\n2.Women's Wear\n3.Back to Previous\n4.Exit");
		int clothingchoice=scan.nextInt();
		switch(clothingchoice)
		{
		case 1:
			new MensWear().menswear();
			break;
		
		case 2:
			new WomensWear().womenswear();
			break;
		
		case 3:
			clothingmenu=false;
			break;
		
		case 4:
			System.out.println("Thank U!!! Please Visit Again");
			System.exit(0);
			break;
			
		default:
			System.out.println("Invalid Choice");
			break;
		}
		}
	}
}
