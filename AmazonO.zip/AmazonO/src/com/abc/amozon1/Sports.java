package com.abc.amozon1;

import java.util.Scanner;

public class Sports {
	
	public static void sports()
	{
		boolean sportsmenu=true;
		boolean cricketmenu;
		boolean badmintonmenu;
		boolean cyclingmenu;
	while(sportsmenu)
	{
		Scanner scan=new Scanner(System.in);
		System.out.println("Welcome to Sports Store");
		System.out.println("Please choose Category \n1.Cricket\n2.Badminton\n3.Cycling\n4.Back to Previous Menu\n5.Exit");
		int cricketoption=scan.nextInt();
		switch(cricketoption)
		{
		case 1:
		cricketmenu=true;
		while(cricketmenu)
		{
			System.out.println("Please select product from below list");
			System.out.printf("%-5s %-30s %-2s %s\n","S.NO","Product",":","Price");
			System.out.printf("%-5s %-30s %-2s %s\n","1","SS Magnum Cricket Bat",":","1,399");
			System.out.printf("%-5s %-30s %-2s %s\n","2","Sunley Pink Leather Ball",":","499");
			System.out.printf("%-5s %-30s %-2s %s\n","3","MRF Cricket Kit Bag",":","1,200");
			System.out.println("4 Back to previous menu");
			int cricketchoice=scan.nextInt();
			switch(cricketchoice)
			{
			case 1:
				String cricket1="SS Magnum Cricket Bat";
				int cricket1Price=1399;
				System.out.println("Enter Quantity");
				int  cricket1q=scan.nextInt();
				new Cart().cart( cricket1,  cricket1q);
				new Cart().price(cricket1,  cricket1Price);
				System.out.println("SS Magnum Cricket Bat added to Shopping Cart");
				System.out.println("**********************");
				break;
			
			case 2:
				String cricket2="Sunley Pink Leather Ball";
				int cricket2Price=499;
				System.out.println("Enter Quantity");
				int  cricket2q=scan.nextInt();
				new Cart().cart( cricket2,  cricket2q);
				new Cart().price(cricket2,  cricket2Price);
				System.out.println("Sunley Pink Leather Ball added to Shopping Cart");
				break;
			
			case 3:
				String cricket3="MRF Cricket Kit Bag";
				int cricket3Price=1200;
				System.out.println("Enter Quantity");
				int  cricket3q=scan.nextInt();
				new Cart().cart( cricket3,  cricket3q);
				new Cart().price(cricket3,  cricket3Price);
				System.out.println("MRF Cricket Kit Bag added to Shopping Cart");
				break;
			
			case 4:
			cricketmenu=false;
			break;
			
			default:
				System.out.println("Invalid choice");
				break;
			}
		}break;
		
		case 2:
			badmintonmenu=true;
			while(badmintonmenu)
			{
				System.out.println("Please select Product from below list");
				System.out.printf("%-5s %-30s %-2s %s\n","S.NO","Product",":","Price");
				System.out.printf("%-5s %-30s %-2s %s\n","1","Yonex Lite Racquet",":","1,540");
				System.out.printf("%-5s %-30s %-2s %s\n","2","Yonex Muscle power Racquet",":","1,990");
				System.out.printf("%-5s %-30s %-2s %s\n","3","Yonex Badminton Kit Bag",":","1,899");
				System.out.println("4.Back to previous menu");
				int badmintonchoice=scan.nextInt();
				switch(badmintonchoice)
				{
				case 1:
					String badminton1="Yonex Lite Racquet";
					int badminton1Price=1540;
					System.out.println("Enter Quantity");
					int  badminton1q=scan.nextInt();
					new Cart().cart( badminton1,  badminton1q);
					new Cart().price(badminton1,  badminton1Price);
					System.out.println("Yonex Lite Racquet added to Shopping Cart");
					System.out.println("**********************");
					break;
				
				case 2:
					String badminton2="Yonex Muscle power Racquet";
					int badminton2Price=1990;
					System.out.println("Enter Quantity");
					int  badminton2q=scan.nextInt();
					new Cart().cart( badminton2,  badminton2q);
					new Cart().price(badminton2,  badminton2Price);
					System.out.println("Yonex Muscle power Racquet added to Shopping Cart");
					System.out.println("**********************");
					break;
				
				case 3:
					String badminton3="Yonex Badminton Kit Bag";
					int badminton3Price=1899;
					System.out.println("Enter Quantity");
					int  badminton3q=scan.nextInt();
					new Cart().cart( badminton3,  badminton3q);
					new Cart().price(badminton3,  badminton3Price);
					System.out.println("Yonex Badminton Kit Bag added to Shopping Cart");
					System.out.println("**********************");
					break;
				
				case 4:
				badmintonmenu=false;
				break;
				default:
					System.out.println("Invalid choice");
					break;
				}
			}break;
			
		case 3:
			cyclingmenu=true;
			while(cyclingmenu)
			{
				System.out.println("Please select product from below list");
				System.out.printf("%-5s %-30s %-2s %s\n","S.NO","Product",":","Price");
				System.out.printf("%-5s %-30s %-2s %s\n","1","Hercules Roadeo A50 cycle",":","12,799");
				System.out.printf("%-5s %-30s %-2s %s\n","2","Cosmic Flash 26T cycle",":","16,499");
				System.out.printf("%-5s %-30s %-2s %s\n","3","Cosmic Trium 21 speed cycle",":","16,999");
				System.out.println("4 Back to previous menu");
				int cyclingchoice=scan.nextInt();
				switch(cyclingchoice)
				{
				case 1:
					String cycling1="Hercules Roadeo A50 cycle";
					int cycling1Price=12799;
					System.out.println("Enter Quantity");
					int  cycling1q=scan.nextInt();
					new Cart().cart( cycling1,  cycling1q);
					new Cart().price(cycling1,  cycling1Price);
					System.out.println("Hercules Roadeo A50 cycle added to Shopping Cart");
					System.out.println("**********************");
					break;
				
				case 2:
					String cycling2="Cosmic Flash 26T cycle";
					int cycling2Price=16499;
					System.out.println("Enter Quantity");
					int  cycling2q=scan.nextInt();
					new Cart().cart( cycling2,  cycling2q);
					new Cart().price(cycling2,  cycling2Price);
					System.out.println("Cosmic Flash 26T cycle added to Shopping Cart");
					System.out.println("**********************");
					break;
				
				case 3:
					String cycling3="Cosmic Trium 21 speed cycle";
					int cycling3Price=16999;
					System.out.println("Enter Quantity");
					int  cycling3q=scan.nextInt();
					new Cart().cart( cycling3,  cycling3q);
					new Cart().price(cycling3,  cycling3Price);
					System.out.println("Cosmic Trium 21 speed cycle added to Shopping Cart");
					System.out.println("**********************");
					break;
				
				case 4:
				cyclingmenu=false;
				break;
				
				default:
					System.out.println("Invalid choice");
					break;
				}
			}break;
			
		case 4:
			sportsmenu=false;
			break;
			
		case 5:
			System.exit(0);
			break;
		
			default:
			System.out.println("Invalid choice");
			break;
			

}
	}
	}

}

