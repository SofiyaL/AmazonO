package com.abc.amozon1;

import java.util.Scanner;

public class WomensWear {

	public static void womenswear()
	{
		boolean womenswearmenu=true;
		boolean kurtasmenu;
		boolean sareesmenu;
		boolean leggingssmenu;
	while(womenswearmenu)
	{
		Scanner scan=new Scanner(System.in);
		System.out.println("Please choose Category \n1.Kurta's\n2.Sarees\n3.Leggings\n4.Back to Previous Menu\n5.Exit");
		int womenswearoption=scan.nextInt();
		switch(womenswearoption)
		{
		case 1:
		kurtasmenu=true;
		while(kurtasmenu)
		{
			System.out.println("Please select product from below list");
			System.out.printf("%-5s %-30s %-2s %s\n","S.NO","Product",":","Price");
			System.out.printf("%-5s %-30s %-2s %s\n","1","Fabindia solid line Kurta",":","1,899");
			System.out.printf("%-5s %-30s %-2s %s\n","2","Libas striped Kurta",":","799");
			System.out.printf("%-5s %-30s %-2s %s\n","3","Soch printed Kurta",":","1,200");
			System.out.println("4 Back to previous menu");
			int kurtaschoice=scan.nextInt();
			switch(kurtaschoice)
			{
			case 1:
				String kurta1="Fabindia solid line Kurta";
				int kurta1Price=1899;
				System.out.println("Enter Quantity");
				int  kurta1q=scan.nextInt();
				new Cart().cart( kurta1,  kurta1q);
				new Cart().price( kurta1,  kurta1Price);
				System.out.println("Fabindia solid line Kurta added to Shopping Cart");
				System.out.println("**********************");
				break;
			
			case 2:
				String kurta2="Libas striped Kurta";
				int kurta2Price=899;
				System.out.println("Enter Quantity");
				int  kurta2q=scan.nextInt();
				new Cart().cart( kurta2,  kurta2q);
				new Cart().price( kurta2,  kurta2Price);
				System.out.println("Libas striped Kurta Formal added to Shopping Cart");
				break;
			
			case 3:
				String kurta3="Soch printed Kurta";
				int kurta3Price=9990;
				System.out.println("Enter Quantity");
				int  kurta3q=scan.nextInt();
				new Cart().cart( kurta3,  kurta3q);
				new Cart().price( kurta3,  kurta3Price);
				System.out.println("Soch printed Kurta added to Shopping Cart");
				break;
			
			case 4:
			kurtasmenu=false;
			break;
			
			default:
				System.out.println("Invalid choice");
				break;
			}
		}break;
		
		case 2:
			sareesmenu=true;
			while(sareesmenu)
			{
				System.out.println("Please select Product from below list");
				System.out.printf("%-5s %-30s %-2s %s\n","S.NO","Product",":","Price");
				System.out.printf("%-5s %-30s %-2s %s\n","1","Soch Printed Saree",":","1,299");
				System.out.printf("%-5s %-30s %-2s %s\n","2","Biba Cotton saree",":","799");
				System.out.printf("%-5s %-30s %-2s %s\n","3","Mitera Silk Saree",":","1,499");
				System.out.println("4.Back to previous menu");
				int bottomwearchoice=scan.nextInt();
				switch(bottomwearchoice)
				{
				case 1:
					String saree1="Soch Printed Saree";
					int saree1Price=1499;
					System.out.println("Enter Quantity");
					int  saree1q=scan.nextInt();
					new Cart().cart( saree1,  saree1q);
					new Cart().price( saree1,  saree1Price);
					System.out.println("Soch Printed Saree added to Shopping Cart");
					System.out.println("**********************");
					break;
				
				case 2:
					String saree2="Biba Cotton saree";
					int saree2Price=899;
					System.out.println("Enter Quantity");
					int  saree2q=scan.nextInt();
					new Cart().cart( saree2,  saree2q);
					new Cart().price( saree2,  saree2Price);
					System.out.println("Biba Cotton saree added to Shopping Cart");
					System.out.println("**********************");
					break;
				
				case 3:
					String saree3="Mitera Silk Saree";
					int saree3Price=1499;
					System.out.println("Enter Quantity");
					int  saree3q=scan.nextInt();
					new Cart().cart( saree3,  saree3q);
					new Cart().price( saree3,  saree3Price);
					System.out.println("Mitera Silk Saree added to Shopping Cart");
					System.out.println("**********************");
					break;
				
				case 4:
				sareesmenu=false;
				break;
				
				default:
					System.out.println("Invalid choice");
					break;
				}
			}break;
			
		case 3:
			leggingssmenu=true;
			while(leggingssmenu)
			{
				System.out.println("Please select product from below list");
				System.out.printf("%-5s %-30s %-2s %s\n","S.NO","Product",":","Price");
				System.out.printf("%-5s %-30s %-2s %s\n","1","Lyra black Leggings",":","999");
				System.out.printf("%-5s %-30s %-2s %s\n","2","TAG 7 Leggings",":","1,299");
				System.out.printf("%-5s %-30s %-2s %s\n","3","H&M Leggings",":","1,599");
				System.out.println("4 Back to previous menu");
				int leggingschoice=scan.nextInt();
				switch(leggingschoice)
				{
				case 1:
					String leggings1="Lyra black Leggings";
					int leggings1Price=999;
					System.out.println("Enter Quantity");
					int  leggings1q=scan.nextInt();
					new Cart().cart( leggings1,  leggings1q);
					new Cart().price( leggings1,  leggings1Price);
					System.out.println("Lyra black Leggings added to Shopping Cart");
					System.out.println("**********************");
					break;
				
				case 2:
					String leggings2="TAG 7 Leggings";
					int leggings2Price=1299;
					System.out.println("Enter Quantity");
					int  leggings2q=scan.nextInt();
					new Cart().cart( leggings2,  leggings2q);
					new Cart().price( leggings2,  leggings2Price);
					System.out.println("TAG 7 Leggings added to Shopping Cart");
					System.out.println("**********************");
					break;
				
				case 3:
					String leggings3="H&M Leggings";
					int leggings3Price=1599;
					System.out.println("Enter Quantity");
					int  leggings3q=scan.nextInt();
					new Cart().cart( leggings3,  leggings3q);
					new Cart().price( leggings3,  leggings3Price);
					System.out.println("H&M Leggings added to Shopping Cart");
					System.out.println("**********************");
					break;
				
				case 4:
					leggingssmenu=false;
				break;
				
				default:
					System.out.println("Invalid choice");
					break;
				}
			}break;
			
		case 4:
			womenswearmenu=false;
			break;
			
		case 5:
			System.exit(0);
			break;
		
			default:
			System.out.println("Invalid choice");
			break;
			

}
	}
}
	}


